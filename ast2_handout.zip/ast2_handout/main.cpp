
#include <iostream>
//Include the cmath and iomanip libraries here

using namespace std;

const int PADDING = 32; //Padding for printing out the distances

int main() {
    //Create the variables for the 2 points (with x and y coordinates) and then prompt the user for the values before reading them
    //Calculate the distances
        //Euclidean distance is the square root of (x2 - x1)^2 + (y2 - y1)^2
        //Manhattan distance is |x2 - x1| + |y2 - y1|
    //Print the distances to standard out in a formatted fashion (Please see sample out from pdf)
        //Print the points to the screen
        //Print the name of the distance aligned to the right using the PADDING followed by the corresponding distance rounded to two places
        //Print the distance between the points visually using as many - characters as the distance, rounded to the nearest integer

    //HINT: The point of this assignment is to become comfortable with C library functions. Please refer to the pdf for descriptions of
    //functions found in cmath and iomanip that may help with formatting and calculations.

    return 0; 
}